addLayer('Denominator',
{
    name          : 'Denominator',
    symbol        : '<h6>1/D(x)</h6>',
    resource      : '无',
    baseResource  : '数字代币',
    baseAmount    :  function()
    {
        return player.points
    },
    color         : 'Lime',
    type          : 'normal',
    exponent      :  1,
    position      :  1,
    row           :  1,
    requires      :  new Decimal(Infinity),
    branches      :  function()
    {
        switch(player.Number.Stage)
        {
            case 1 :
            case 2 : 
            case 3 : return ['Number']; break
            default: break;
        }
    },

    resetDescription : '',

    hotkeys : 
    [

    ],

    tooltip :  function()
    {
        return 'DD: ' + format(player.Denominator.Data) + '<br>Effect: ÷' + format(player.Denominator.Denominator_Multi)
    },

    tabFormat :
    {
        'Main':
        {
            unlocked : true,
            content  : function()
            {
                var Format = []
                Format.push(['row',[
                                ['column',[
                                    ['display-text','<h2>Denominator Effect</h2>'],
                                    'blank',
                                    ['display-text','<h1>' + format(player.Denominator.Denominator_Multi + '</h1>')],],{'height':'90px','width':'350px','border':'2px white solid','border-radius':'20px'}],
                                ['column',[
                                    ['display-text','<h1 style="font-size:50px">←</h1>']],{'width':'50px'}],
                                ['column',[
                                    ['display-text','<h2>Denominator Data</h2>'],
                                    'blank',
                                    ['display-text','<h1>' + format(player.Denominator.Data + '</h1>')],],{'height':'90px','width':'350px','border':'2px white solid','border-radius':'20px'}],],{}])
                Format.push(['row',[
                                ['column',,{'width':'400px'}],
                                ['column',[
                                    ['display-text','<h1 style="font-size:50px">↑</h1>'],
                                    ['column',[
                                        ['display-text','<h2>DD. Gain</h2>'],
                                        'blank',
                                        ['display-text','<h1>+' + format(player.Denominator.Data_Gain_Total) + '/s</h1>'],],{'height':'90px','width':'350px','border':'2px white solid','border-radius':'20px'}],],{'width':'350px'}],],{}])
                Format.push(['row',[
                                ['column',[
                                    ['column',[
                                        ['column',[
                                            ['display-text','<h1>×' + format(player.Denominator.Data_Gain_Mul) + ',^' + format(player.Denominator.Data_Gain_Exp)]],{'position':'absolute','right':'0'}],],{'width':'300px','transform':'translate(215px,-14px)'}]],{'width':'405px'}],
                                ['column',[
                                    ['display-text','<h1 style="font-size:50px">↑</h1>'],],{'width':'350px'}],],{}])
                Format.push(['h-line','900px'])
                Format.push('blank')
                Format.push(['column',[
                                ['clickable',2],
                                ['display-text','<h1 style="font-size:40px">↑</h1>'],
                                ['row',[
                                    ['clickable',4],
                                    ['column',[
                                        ['display-text',player.Denominator.Variable[3][3]?'<h1 style="font-size:40px">←</h1>':'']],{'width':'40px'}],
                                    ['clickable',1],
                                    ['column',[
                                        ['display-text',player.Denominator.Variable[4][3]?'<h1 style="font-size:40px">→</h1>':'']],{'width':'40px'}],
                                    ['clickable',5],],{}],
                                ['display-text',player.Denominator.Variable[2][3]?'<h1 style="font-size:40px">↓</h1>':''],
                                ['clickable',3],],{}])
                return Format
            }
        },
        'Upgrades':
        {
            unlocked : function()
            {
                return player.Number.Stage > 1
            },
            content  : function()
            {
                var Format = []
                Format.push(['row',[
                                ['column',[
                                    ['display-text','<h2>DD. Gain</h2>'],
                                    'blank',
                                    ['display-text','<h1>+' + format(player.Denominator.Data_Gain_Total) + '/s</h1>'],],{'height':'90px','width':'350px','border':'2px white solid','border-radius':'20px'}],
                                ['column',[
                                    ['display-text','<h1 style="font-size:50px">→</h1>']],{'width':'50px'}],
                                ['column',[
                                    ['display-text','<h2>Denominator Data</h2>'],
                                    'blank',
                                    ['display-text','<h1>' + format(player.Denominator.Data + '</h1>')],],{'height':'90px','width':'350px','border':'2px white solid','border-radius':'20px'}],],{}])
                Format.push(['row',[
                                ['column',,{'width':'405px'}],
                                ['column',[
                                    ['display-text','<h1 style="font-size:50px">↓</h1>'],],{'width':'350px'}],],{}])
                Format.push(['h-line','900px'])
                Format.push('blank','blank','blank')
                Format.push(['row',[
                                ['clickable',12],
                                ['column',,{'width':'54px'}],
                                ['clickable',11]],{}])
                return Format
            }
        }
    },

    microtabs:
    {

    },

    layerShown :  function()
    {
        return true
    },
    
    startData :  function()
    {    
        return{
        unlocked    : true,
		points      : new Decimal(10),
        Stop        : 0,

        Data              : new Decimal(10),
        Data_Gain_Base    : new Decimal(0),
        Data_Gain_Mul     : new Decimal(1),
        Data_Gain_Exp     : new Decimal(1),
        Data_Gain_Total   : new Decimal(0),

        Denominator_Multi : new Decimal(1),

        Imaginary_Number  : new Decimal(0),
                          // 0.PlaceHolder, 1.Input,        2.Output,         3.Inputting
        Imaginary_IO      : [0,             new Decimal(2), new Decimal(0.1), 0],

                             // 0.PlaceHolder, 1.Number,       2.Effect,       3.Unlock, 4.Choosen
        Variable          : [0,[0,             new Decimal(0), new Decimal(0) ,1,        0,],
                               [0,             new Decimal(0), new Decimal(0) ,0,        0,],
                               [0,             new Decimal(0), new Decimal(0) ,0,        0,],
                               [0,             new Decimal(0), new Decimal(0) ,0,        0,],],
        
                                 // 0.PlaceHolder, 1.Level,        2.Effect,       3.Price
        Denominator_Clickables :[0,[0,             new Decimal(0), new Decimal(0), new Decimal(0)],
                                   [0,             new Decimal(0), new Decimal(0), new Decimal(0)],
                                   [0,             new Decimal(0), new Decimal(0), new Decimal(0)],]
        }
    },
        
    gainMult :  function()
    {
        mult = new Decimal(1)
        return mult
    },

    gainExp :  function()
    {
        exp = new Decimal(1)
        return exp
    },

    update :  function(diff)
    {
        if(!player.Denominator.Stop)
        {
            // Denominator Upgrade 相关函数 -------------------------------------------------------------------------------------------------------------------
            player.Denominator.Denominator_Clickables[1][2] = player.Denominator.Denominator_Clickables[1][1].mul(0.05).add(1).max(1)
            player.Denominator.Denominator_Clickables[1][3] = new Decimal(1.25).pow(player.Denominator.Denominator_Clickables[1][1]).mul(25)
            player.Denominator.Denominator_Clickables[2][2] = player.Denominator.Denominator_Clickables[2][1].add(1).max(1)
            player.Denominator.Denominator_Clickables[2][3] = player.Denominator.Denominator_Clickables[2][1].add(1).pow(1.5).mul(500)
            
            // Variable X 相关函数 ----------------------------------------------------------------------------------------------------------------------------
            player.Denominator.Variable[1][2] = player.Denominator.Variable[1][1].sqrt() 

            // Denominator Imput 相关函数 ---------------------------------------------------------------------------------------------------------------------
            player.Denominator.Imaginary_IO[1] = new Decimal(2)
            player.Denominator.Imaginary_IO[1] = player.Denominator.Imaginary_IO[1].mul(player.Denominator.Denominator_Clickables[2][2])
            if(player.Denominator.Imaginary_IO[3] == 1)
            {
                if(player.Denominator.Imaginary_IO[1].mul(diff).lte(player.Denominator.Data))
                {
                    player.Denominator.Imaginary_Number = player.Denominator.Imaginary_Number.add(player.Denominator.Imaginary_IO[1].mul(diff))
                    player.Denominator.Data             = player.Denominator.Data.sub(player.Denominator.Imaginary_IO[1].mul(diff))
                }
                else
                {
                    player.Denominator.Imaginary_Number = player.Denominator.Imaginary_Number.add(player.Denominator.Data)
                    player.Denominator.Data             = new Decimal(0)
                }
            }

            // Denominator Output 相关函数 --------------------------------------------------------------------------------------------------------------------
            var Output = player.Denominator.Imaginary_IO[2].mul(player.Denominator.Imaginary_Number).mul(diff)
            var Direction = 0
            for(var I=1; I<5; I++)
            {
                Direction += player.Denominator.Variable[I][4]
            }
            for(var I=1; I<5; I++)
            {
                if(player.Denominator.Variable[I][4] == 1) player.Denominator.Variable[I][1] = player.Denominator.Variable[I][1].add(Output.div(Math.max(Direction,1)))
            }
            if(Direction !== 0)player.Denominator.Imaginary_Number = player.Denominator.Imaginary_Number.sub(Output)

            // Denominator Data 相关函数 ----------------------------------------------------------------------------------------------------------------------
            player.Denominator.Data_Gain_Exp   = new Decimal(1)
            player.Denominator.Data_Gain_Mul   = new Decimal(1)
            player.Denominator.Data_Gain_Mul   = player.Denominator.Data_Gain_Mul.mul(player.Denominator.Denominator_Clickables[1][2])
            player.Denominator.Data_Gain_Base  = new Decimal(0)
            player.Denominator.Data_Gain_Base  = player.Denominator.Data_Gain_Base.add(player.Denominator.Variable[1][2])
            player.Denominator.Data_Gain_Total = player.Denominator.Data_Gain_Base.mul(player.Denominator.Data_Gain_Mul).pow(player.Denominator.Data_Gain_Exp)
            player.Denominator.Data   = player.Denominator.Data.add((player.Denominator.Data_Gain_Total).mul(diff))
    
            // Denominator Effect 相关函数 --------------------------------------------------------------------------------------------------------------------
            player.Denominator.Denominator_Multi = player.Denominator.Data.max(2500).log(2500).pow(0.5) 
            
        }  
    },

    doReset :  function(Resetting_Layer)
    {
        
    },

    milestones :
    {

    },

    bars:
    {

    },

    clickables : (()=>
    {
        var Clickables = {}

        // Clickables[1] Mid Button ---------------------------------------------------------------------------------------------------------------------------
        Clickables[1] = {}
        Clickables[1].title = function()
        {
            return '<h3>Imaginary Number'
        }
        Clickables[1].display = function()
        {
            var Input  = '<h2>Input<br>'    + format(player.Denominator.Imaginary_IO[1])  + '</h3>'
            var Output = '<h2>Output<br>'   + format(player.Denominator.Imaginary_IO[2].mul(100))  + '%</h3>'
            var Number = '<h2>Quantity<br>' + format(player.Denominator.Imaginary_Number) + '</h3>'
            return '-------------------------------------<br><br>' + Input + '<br><br>' + Output + '<br><br>' + Number
        }
        Clickables[1].canClick = function()
        {
            return true
        }
        Clickables[1].onClick = function()
        {
            switch(player.Denominator.Imaginary_IO[3])
            {
                case 1: player.Denominator.Imaginary_IO[3] = 0; break
                case 0: player.Denominator.Imaginary_IO[3] = 1; break
            }
        }
        Clickables[1].style = function()
        {
            var Style = {}
            Style['width']                = '250px'
            Style['height']               = '250px'
            Style['border']               = '2px solid white'
            Style['border-radius']        = '5px'
            Style['color']                = 'white'
            Style['background-color']     = 'black'
            if(player.Denominator.Imaginary_IO[3] == 1)
            {
                Style['background-color'] = 'DarkGreen'
            }
            return Style
        }

        // Clickables[2-5] Variabels --------------------------------------------------------------------------------------------------------------------------
        for(var I=2; I<=5; I++)  Clickables[I] = {}
        Clickables[2].title = function()
        {
            var Title  = 'Variable X'
            var Discription = 'Produce DD.'
            var Effect = 'Effect<br>+' + format(player.Denominator.Variable[1][2]) + '/s'
            return Title + '<br>----------------<br><br>' + Discription + '<br><br>' + Effect
        }
        Clickables[3].title = function()
        {
            return 'Variable I'
        }
        Clickables[4].title = function()
        {
            return 'Variable J'
        }
        Clickables[5].title = function()
        {
            return 'Variable K'
        }
        for(var I=2; I<=5; I++)
        {
            Clickables[I].canClick = function()
            {
                return player.Denominator.Variable[this.id-1][3]
            }
            Clickables[I].onClick = function()
            {
                switch(player.Denominator.Variable[this.id-1][4])
                {
                    case 0: player.Denominator.Variable[this.id-1][4] = 1; break
                    case 1: player.Denominator.Variable[this.id-1][4] = 0; break
                }
            }
            Clickables[I].style = function()
            {
                var Style = {}
                Style['width']                = '200px'
                Style['height']               = '200px'
                Style['border']               = '2px solid white'
                Style['border-radius']        = '5px'
                Style['color']                = 'white'
                Style['background-color']     = 'black'
                if(player.Denominator.Variable[this.id-1][3] == 0)
                {
                    Style['opacity']          = '0'
                }
                if(player.Denominator.Variable[this.id-1][4] == 1)
                {
                    Style['background-color'] = 'DarkGreen'
                }
                return Style
            }
        }

        // Upgrades [1~3]--------------------------------------------------------------------------------------------------------------------------------------
        for(var I=11; I<13; I++)
        {
            Clickables[I] = {}
            Clickables[I].canClick = function()
            {
                return player.Denominator.Denominator_Clickables[this.id-10][3].lte(player.Denominator.Data)
            }
            Clickables[I].onClick = function()
            {
                player.Denominator.Data                                  = player.Denominator.Data.sub(player.Denominator.Denominator_Clickables[this.id-10][3])
                player.Denominator.Denominator_Clickables[this.id-10][1] = player.Denominator.Denominator_Clickables[this.id-10][1].add(1)
            }
            Clickables[I].onHold = Clickables[I].onClick
            Clickables[I].style = function()
            {
                var Style = {}
                Style['width']                = '200px'
                Style['height']               = '200px'
                Style['border']               = '2px solid white'
                Style['border-radius']        = '5px'
                Style['color']                = 'white'
                Style['background-color']     = 'black'
                if(!this.canClick())
                {
                    Style['border']           = '2px solid #666666'
                    Style['color']            = '#666666'
                }
                return Style
            }
        }

        Clickables[11].title = 'Denominator Multiples'
        Clickables[11].display = function()
        {
            var Description = '<h3>Increse the multiple of NI. Gain'
            var Effect      = '<h2>×' + format(player.Denominator.Denominator_Clickables[1][2]) + '</h2>'
            var Price       = '<h2> ' + format(player.Denominator.Denominator_Clickables[1][3]) + ' DD.</h2>'
            return '<h3>---------------------<br>' + Description + '<br><br>' + Effect + '<br><h3>---------------------</h3><br>' + Price
        }

        Clickables[12].title = 'Larger Modulus'
        Clickables[12].display = function()
        {
            var Description = '<h3>Increase the input amount of DD.'
            var Effect      = '<h2>×' + format(player.Denominator.Denominator_Clickables[2][2]) + '</h2>'
            var Price       = '<h2> ' + format(player.Denominator.Denominator_Clickables[2][3]) + ' DD.</h2>'
            return '<h3>---------------------<br>' + Description + '<br><br>' + Effect + '<br><h3>---------------------</h3><br>' + Price
        }

        return Clickables
    })()
})