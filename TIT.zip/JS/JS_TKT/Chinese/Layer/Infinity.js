addLayer('Infinity',
{
    name          : 'Infinity',
    symbol        : '<h6><font style="color:white">Inf.</h6>',
    resource      : '无',
    baseResource  : '数字代币',
    baseAmount    :  function()
    {
        return player.points
    },
    color         : 'black',
    type          : 'normal',
    exponent      :  1,
    position      :  2,
    row           :  0,
    requires      :  new Decimal(Infinity),
    branches      :  function()
    {
        switch(player.Number.Stage)
        {
            case 3: return ['Number']; break
            default: break;
        }
    },

    resetDescription : '',

    hotkeys : 
    [

    ],

    tooltip :  function()
    {
        return 'PI: ' + format(player.Infinity.Points)
    },

    tabFormat :
    {
        'Main':
        {
            unlocked : true,
            content  : function()
            {
                var Format = []
                return Format
            }
        },
        'Upgrades':
        {
            unlocked : function()
            {
                return player.Number.Stage > 1
            },
            content : function()
            {
                var Format = []
                return Format
            } 
        }
    },

    microtabs:
    {

    },

    layerShown :  function()
    {
        return (player.Number.Stage>=3)
    },
    
    startData :  function()
    {    
        return{
        unlocked               : true,
		points                 : new Decimal(0),
        Stop                   : 0,

        Points                 : new Decimal(0),
        }
    },
        
    gainMult :  function()
    {
        mult = new Decimal(1)
        return mult
    },

    gainExp :  function()
    {
        exp = new Decimal(1)
        return exp
    },

    update :  function(diff)
    {
        if(!player.Infinity.Stop)
        {
            
        }
    },

    doReset :  function(Resetting_Layer)
    {
        
    },

    milestones :
    {

    },

    bars:
    {

    },

    clickables :  (()=>
    {
        var Clickables = {}
        return Clickables
    })()
})